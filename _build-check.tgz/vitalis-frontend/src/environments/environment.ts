export const environment = {
  production: false,
  apiUrl: 'http://localhost:5004/api',
  serverUrl: 'http://localhost:5004'
};
